﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C__lab_day_6_Q_3
{
    internal class Class1
    {
        static void Main(string[] args)
        {
            Dog myDog = new Dog();
            myDog.Animal();
            myDog.Dog();
        }
    }
}
